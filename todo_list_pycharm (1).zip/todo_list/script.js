// Тапсырмалар браузердің localStorage жадында сақталады.
const STORAGE_KEY = "taskflow_tasks_v1";

function readTasks() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
  } catch (error) {
    return [];
  }
}

function saveTasks(tasks) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
}

const taskForm = document.getElementById("taskForm");

if (taskForm) {
  const titleInput = document.getElementById("taskTitle");
  const priorityInput = document.getElementById("taskPriority");
  const dateInput = document.getElementById("taskDate");
  const searchInput = document.getElementById("searchInput");
  const statusFilter = document.getElementById("statusFilter");
  const taskList = document.getElementById("taskList");
  const emptyMessage = document.getElementById("emptyMessage");

  taskForm.addEventListener("submit", function (event) {
    event.preventDefault();
    const title = titleInput.value.trim();

    // Бос тапсырма қосылуына жол бермейміз.
    if (!title) {
      titleInput.focus();
      return;
    }

    const tasks = readTasks();
    tasks.unshift({
      id: Date.now(),
      title: title,
      priority: priorityInput.value,
      dueDate: dateInput.value,
      completed: false
    });

    saveTasks(tasks);
    taskForm.reset();
    renderTasks();
    titleInput.focus();
  });

  searchInput.addEventListener("input", renderTasks);
  statusFilter.addEventListener("change", renderTasks);

  function renderTasks() {
    const tasks = readTasks();
    const query = searchInput.value.trim().toLocaleLowerCase("kk");
    const filter = statusFilter.value;

    document.getElementById("totalCount").textContent = tasks.length;
    document.getElementById("doneCount").textContent = tasks.filter(task => task.completed).length;
    document.getElementById("remainingCount").textContent = tasks.filter(task => !task.completed).length;

    const visibleTasks = tasks.filter(task => {
      const matchesText = task.title.toLocaleLowerCase("kk").includes(query);
      const matchesStatus = filter === "all" ||
        (filter === "done" && task.completed) ||
        (filter === "active" && !task.completed);
      return matchesText && matchesStatus;
    });

    taskList.replaceChildren();
    emptyMessage.hidden = visibleTasks.length > 0;
    emptyMessage.textContent = tasks.length === 0
      ? "Әзірге тапсырма жоқ. Жоғарыдағы өріске алғашқы тапсырмаңды енгіз."
      : "Сұрауыңа сәйкес тапсырма табылмады.";

    visibleTasks.forEach(task => {
      // DOM элементтерін қолданып, пайдаланушы мәтінін HTML ретінде орындамаймыз.
      const row = document.createElement("div");
      row.className = "task-row";

      const check = document.createElement("button");
      check.type = "button";
      check.className = "task-check" + (task.completed ? " checked" : "");
      check.textContent = task.completed ? "✓" : "";
      check.setAttribute("aria-label", task.completed ? "Орындалмаған деп белгілеу" : "Орындалды деп белгілеу");
      check.addEventListener("click", () => {
        updateTask(task.id, item => { item.completed = !item.completed; });
      });

      const details = document.createElement("div");
      details.className = "task-details";
      const title = document.createElement("div");
      title.className = "task-title" + (task.completed ? " completed" : "");
      title.textContent = task.title;

      const meta = document.createElement("div");
      meta.className = "task-meta";
      const priority = document.createElement("span");
      priority.className = "tag" + (task.priority === "Шұғыл" ? " urgent" : "");
      priority.textContent = task.priority;
      meta.appendChild(priority);

      if (task.dueDate) {
        const date = document.createElement("span");
        date.textContent = "Мерзімі: " + task.dueDate;
        meta.appendChild(date);
      }

      details.append(title, meta);

      const edit = document.createElement("button");
      edit.type = "button";
      edit.className = "delete-btn";
      edit.textContent = "Өңдеу";
      edit.setAttribute("aria-label", "Тапсырманы өңдеу");
      edit.addEventListener("click", () => {
        const newTitle = prompt("Тапсырманың жаңа атауын енгіз:", task.title);
        if (newTitle === null) return;
        if (!newTitle.trim()) {
          alert("Тапсырма атауы бос болмауы керек.");
          return;
        }
        updateTask(task.id, item => { item.title = newTitle.trim(); });
      });

      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "delete-btn";
      remove.textContent = "Жою";
      remove.setAttribute("aria-label", "Тапсырманы жою");
      remove.addEventListener("click", () => {
        if (!confirm("Осы тапсырманы жойғың келе ме?")) return;
        saveTasks(readTasks().filter(item => item.id !== task.id));
        renderTasks();
      });

      row.append(check, details, edit, remove);
      taskList.appendChild(row);
    });
  }

  function updateTask(id, change) {
    const tasks = readTasks();
    const task = tasks.find(item => item.id === id);
    if (!task) return;
    change(task);
    saveTasks(tasks);
    renderTasks();
  }

  renderTasks();
}

// Кіру формасының бастапқы тексерісі. Нақты авторизация PHP арқылы жасалады.
const loginForm = document.getElementById("loginForm");
if (loginForm) {
  loginForm.addEventListener("submit", function (event) {
    event.preventDefault();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;
    const message = document.getElementById("loginMessage");

    if (!email || password.length < 6) {
      message.textContent = "Электрондық пошта мен кемінде 6 таңбалы құпиясөзді енгіз.";
      return;
    }

    message.textContent = "Форма тексерілді. Нақты кіру жүйесін қосу үшін PHP сервері қажет.";
  });
}
